# 云端天气 · Galaxy Watch8 / Wear OS

适配自用户提供的 `CloudSky-Weather-Android-V2.zip`，沿用其 Open-Meteo 网络请求、JSON 字段、城市匹配和缓存策略。这个版本是独立手表天气 APK，不是表盘。

## 功能保留
- 全球城市搜索（支持中文/英文/西语；实际语言覆盖由 Open-Meteo 地名数据库决定）
- 相同城市名称时列出最多 8 个匹配候选
- 通过手表网络/GPS定位：点击后首次申请权限
- 当前气温/天气、体感、湿度、风速、降水量
- 未来24小时逐小时气温、天气、降雨概率：横向滑动
- 未来7天最高/最低温度及降雨概率
- 手动刷新；最近数据离线缓存；记忆上次查看的城市
- 中文界面；默认 Buenos Aires, Argentina（不是实际定位）

## Watch8 适配
- 圆屏安全边距、纯黑 AMOLED、省电（不设置常亮、不启用后台服务或悬浮窗）
- 简化主界面，城市搜索为独立页面，使用系统手表输入法
- 每个刷新、定位、搜索按钮都采用较大的点击区域
- 无第三方库；独立 Wear OS 应用声明；不要求搭配手机 App
- 独立 package `com.cloudsky.weather.watch`，与原手机天气 App 可同时安装

## 手机上通过 GitHub Actions 编译 APK
1. 新建仓库建议 `Watch8-CloudSky-Weather`：https://github.com/new
2. 上传完整 `CloudSky-Weather-Watch8-v1-OneUpload.zip` 到仓库**根目录**（不解压）。
3. 在仓库里创建 `.github/workflows/build-apk.yml` 并粘贴所附同名编译代码（单独的 TXT / YML 文件提供）。如果已解压整个源码上传，工作流也能直接编译。
4. Actions > Build Watch8 CloudSky Weather APK > Run workflow > 成功后下载 `CloudSky-Weather-Watch8-v1-APK`，解压得到 APK。
5. 用 Wear Installer 2 或 ADB 安装到 Galaxy Watch8。手表需要可用的网络；第一次定位可能需要授予位置权限。.

本项目复用原版的 Open-Meteo 免费天气接口，仅用于许可范围内；保留 `Open-Meteo.com` / `GeoNames` 署名。若用于商业分发，请核查 Open-Meteo 的商业授权与数据使用限制。

构建配置：Java 17 / Gradle 8.11.1 / Android Gradle Plugin 8.9.2 / SDK 35 / minSdk 30 / targetSdk 35。原 ZIP 中只提供原生 Java 框架 UI 和网络逻辑，不包含 Google Play 认证、配套手机端、后台天气并发更新或者表盘 complication。

**验证说明**：本地已执行源码结构和静态检查；由于本环境没有 Android SDK，尚未真正完成 APK 编译，需在 GitHub Actions 构建后到 Watch8 上测试。
